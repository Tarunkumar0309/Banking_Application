Banking Application (Flask microservices + minimal Angular skeleton)
-----------------------------------------------------------------
Contents:
- api_gateway/           : Minimal gateway stub (optional)
- account_service/       : Flask app (users + accounts) with JWT auth
- transaction_service/   : Flask app (transactions) that calls account service
- shared/                : shared utils/constants
- angular_frontend/      : Minimal Angular-like static skeleton (not a full Angular CLI project)
- run_instructions.txt   : How to run services locally (venv + pip)

Notes:
- Both services use SQLite (SQLAlchemy). Databases are in each service's directory (sqlite files).
- JWT handled by flask_jwt_extended.
- Inter-service communication uses HTTP requests (requests library). For production use mTLS or service mesh.
- This is a functional starter project for local testing. Adjust secrets, CORS and security for production.
