from flask import Blueprint, request, jsonify
from .models import User, Account, db
from .utils import hash_password, verify_password
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity, get_jwt
import datetime

bp = Blueprint('account', __name__)

@bp.route('/auth/register', methods=['POST'])
def register():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'msg': 'username and password required'}), 400
    if User.query.filter_by(username=data['username']).first():
        return jsonify({'msg': 'username exists'}), 400
    user = User(username=data['username'],
                password=hash_password(data['password']),
                role=data.get('role','USER'),
                name=data.get('name'),
                address=data.get('address'),
                phoneno=data.get('phoneno'),
                email=data.get('email'))
    db.session.add(user)
    db.session.commit()
    return jsonify({'msg':'user created','user_id':user.user_id}),201

@bp.route('/auth/login', methods=['POST'])
def login():
    data = request.get_json()
    if not data or not data.get('username') or not data.get('password'):
        return jsonify({'msg':'username and password required'}),400
    user = User.query.filter_by(username=data['username']).first()
    if not user or not verify_password(data['password'], user.password):
        return jsonify({'msg':'bad username or password'}),401
    additional_claims = {'role': user.role}
    access_token = create_access_token(identity=user.user_id, additional_claims=additional_claims)
    return jsonify({'access_token': access_token, 'user_id': user.user_id, 'role': user.role})

@bp.route('/accounts', methods=['POST'])
@jwt_required()
def open_account():
    user_id = get_jwt_identity()
    acc = Account(user_id=user_id, balance=request.json.get('initial_deposit', 0.0), status='ACTIVE')
    db.session.add(acc)
    db.session.commit()
    return jsonify({'account_id': acc.account_id, 'balance': acc.balance}),201

@bp.route('/accounts/me', methods=['GET'])
@jwt_required()
def get_my_accounts():
    user_id = get_jwt_identity()
    accounts = Account.query.filter_by(user_id=user_id).all()
    res = [{'account_id':a.account_id,'balance':a.balance,'status':a.status} for a in accounts]
    return jsonify(res)

@bp.route('/accounts', methods=['GET'])
@jwt_required()
def get_all_accounts():
    claims = get_jwt()
    if claims.get('role') != 'ADMIN':
        return jsonify({'msg':'admin required'}),403
    accounts = Account.query.all()
    res = [{'account_id':a.account_id,'user_id':a.user_id,'balance':a.balance,'status':a.status} for a in accounts]
    return jsonify(res)

@bp.route('/accounts/<int:account_id>', methods=['DELETE'])
@jwt_required()
def close_account(account_id):
    claims = get_jwt()
    if claims.get('role') != 'ADMIN':
        return jsonify({'msg':'admin required'}),403
    acc = Account.query.get_or_404(account_id)
    acc.status='CLOSED'
    db.session.commit()
    return jsonify({'msg':'closed'})

# Internal endpoint for checking balance (public read but intended for internal use)
@bp.route('/accounts/<int:account_id>', methods=['GET'])
def check_balance(account_id):
    acc = Account.query.get_or_404(account_id)
    return jsonify({'account_id':acc.account_id,'balance':acc.balance,'status':acc.status})

# Internal endpoint for updating balance (called by Transaction Service)
@bp.route('/accounts/<int:account_id>/balance', methods=['PATCH'])
def update_balance(account_id):
    acc = Account.query.get_or_404(account_id)
    data = request.get_json() or {}
    new_balance = data.get('balance')
    if new_balance is None:
        return jsonify({'msg':'balance required'}),400
    acc.balance = float(new_balance)
    db.session.commit()
    return jsonify({'account_id':acc.account_id,'balance':acc.balance})
