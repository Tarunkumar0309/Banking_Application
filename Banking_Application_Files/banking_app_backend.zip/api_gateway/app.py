from flask import Flask, jsonify
app = Flask(__name__)

@app.route('/')
def hello():
    return jsonify({'msg':'API Gateway - minimal. Start account_service and transaction_service separately.'})

if __name__ == '__main__':
    app.run(port=5000, debug=True)
