from flask import Blueprint, request, jsonify
from .models import Transaction, db
import requests
from shared.constants import ACCOUNT_SERVICE_URL

bp = Blueprint('txn', __name__)

def get_account(account_id):
    r = requests.get(f"{ACCOUNT_SERVICE_URL}/accounts/{account_id}")
    if r.status_code != 200:
        return None
    return r.json()

def update_account_balance(account_id, new_balance):
    r = requests.patch(f"{ACCOUNT_SERVICE_URL}/accounts/{account_id}/balance", json={'balance': new_balance})
    return r.status_code == 200

@bp.route('/transactions/deposit', methods=['POST'])
def deposit():
    data = request.get_json()
    account_id = data.get('account_id'); amount = float(data.get('amount',0))
    if amount <= 0:
        return jsonify({'msg':'invalid amount'}),400
    acc = get_account(account_id)
    if not acc or acc.get('status') != 'ACTIVE':
        return jsonify({'msg':'account not available'}),404
    new_balance = acc['balance'] + amount
    ok = update_account_balance(account_id, new_balance)
    txn = Transaction(account_id=account_id, type='DEPOSIT', amount=amount, status='SUCCESS' if ok else 'FAILED')
    db.session.add(txn); db.session.commit()
    return jsonify({'transaction_id':txn.transaction_id,'status':txn.status,'new_balance':new_balance if ok else acc['balance']})

@bp.route('/transactions/withdraw', methods=['POST'])
def withdraw():
    data = request.get_json()
    account_id = data.get('account_id'); amount = float(data.get('amount',0))
    if amount <= 0:
        return jsonify({'msg':'invalid amount'}),400
    acc = get_account(account_id)
    if not acc or acc.get('status') != 'ACTIVE':
        return jsonify({'msg':'account not available'}),404
    if acc['balance'] < amount:
        txn = Transaction(account_id=account_id, type='WITHDRAW', amount=amount, status='FAILED')
        db.session.add(txn); db.session.commit()
        return jsonify({'msg':'insufficient funds'}),400
    new_balance = acc['balance'] - amount
    ok = update_account_balance(account_id, new_balance)
    txn = Transaction(account_id=account_id, type='WITHDRAW', amount=amount, status='SUCCESS' if ok else 'FAILED')
    db.session.add(txn); db.session.commit()
    return jsonify({'transaction_id':txn.transaction_id,'status':txn.status,'new_balance':new_balance if ok else acc['balance']})

@bp.route('/transactions/transfer', methods=['POST'])
def transfer():
    data = request.get_json()
    from_ac = data.get('from_account'); to_ac = data.get('to_account'); amount = float(data.get('amount',0))
    if amount <= 0:
        return jsonify({'msg':'invalid amount'}),400
    src = get_account(from_ac); dst = get_account(to_ac)
    if not src or src.get('status')!='ACTIVE' or not dst or dst.get('status')!='ACTIVE':
        return jsonify({'msg':'account missing'}),404
    if src['balance'] < amount:
        txn = Transaction(account_id=from_ac, type='TRANSFER', amount=amount, status='FAILED', meta=f'to:{to_ac}')
        db.session.add(txn); db.session.commit()
        return jsonify({'msg':'insufficient funds'}),400
    # update balances
    ok1 = update_account_balance(from_ac, src['balance'] - amount)
    ok2 = update_account_balance(to_ac, dst['balance'] + amount)
    status = 'SUCCESS' if ok1 and ok2 else 'FAILED'
    txn = Transaction(account_id=from_ac, type='TRANSFER', amount=amount, status=status, meta=f'to:{to_ac}')
    db.session.add(txn); db.session.commit()
    return jsonify({'transaction_id':txn.transaction_id,'status':txn.status})

@bp.route('/transactions/<int:account_id>', methods=['GET'])
def history(account_id):
    txns = Transaction.query.filter_by(account_id=account_id).order_by(Transaction.timestamp.desc()).all()
    res = [{'transaction_id':t.transaction_id,'type':t.type,'amount':t.amount,'timestamp':t.timestamp.isoformat(),'status':t.status,'meta':t.meta} for t in txns]
    return jsonify(res)

@bp.route('/transactions', methods=['GET'])
def list_all():
    txns = Transaction.query.order_by(Transaction.timestamp.desc()).all()
    res = [{'transaction_id':t.transaction_id,'account_id':t.account_id,'type':t.type,'amount':t.amount,'timestamp':t.timestamp.isoformat(),'status':t.status} for t in txns]
    return jsonify(res)
